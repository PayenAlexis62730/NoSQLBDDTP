<?php
echo phpinfo();