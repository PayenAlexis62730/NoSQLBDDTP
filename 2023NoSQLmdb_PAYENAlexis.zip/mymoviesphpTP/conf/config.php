<?php
// Vous pouvez vous amuser à créer des fausses pistes avec des données inutilisées ^^_^^
$parameters['host'] = 'localhost';
$parameters['port'] = '8099';
$parameters['username'] = 'fakeuser';
$parameters['password'] = 'fakepass';
$parameters['dbname'] = 'fakedbname';
$parameters['dbprefix'] = 'pdb_';